const axios = require("axios");

const GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_URL = "https://api.open-meteo.com/v1/forecast";

// Maps Open-Meteo's numeric weather codes to a human-readable description.
const WEATHER_CODES = {
  0: "Clear sky",
  1: "Mainly clear",
  2: "Partly cloudy",
  3: "Overcast",
  45: "Fog",
  48: "Depositing rime fog",
  51: "Light drizzle",
  53: "Moderate drizzle",
  55: "Dense drizzle",
  61: "Slight rain",
  63: "Moderate rain",
  65: "Heavy rain",
  71: "Slight snow fall",
  73: "Moderate snow fall",
  75: "Heavy snow fall",
  80: "Slight rain showers",
  81: "Moderate rain showers",
  82: "Violent rain showers",
  95: "Thunderstorm",
  96: "Thunderstorm with slight hail",
  99: "Thunderstorm with heavy hail",
};

function describeCode(code) {
  return WEATHER_CODES[code] || "Unknown";
}

/**
 * Converts a city name into latitude/longitude using Open-Meteo's free
 * geocoding API. Throws an error with a `status` property if the city
 * can't be found, so route handlers can map it to the right HTTP code.
 */
async function geocodeCity(city) {
  const { data } = await axios.get(GEOCODE_URL, {
    params: { name: city, count: 1, language: "en", format: "json" },
  });

  if (!data.results || data.results.length === 0) {
    const err = new Error(`City "${city}" not found`);
    err.status = 404;
    throw err;
  }

  const place = data.results[0];
  return {
    name: place.name,
    country: place.country,
    latitude: place.latitude,
    longitude: place.longitude,
  };
}

/**
 * Fetches current weather for a given latitude/longitude.
 */
async function getCurrentWeather(latitude, longitude) {
  const { data } = await axios.get(WEATHER_URL, {
    params: {
      latitude,
      longitude,
      current: "temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code",
      timezone: "auto",
    },
  });

  const current = data.current;
  return {
    temperature_celsius: current.temperature_2m,
    humidity_percent: current.relative_humidity_2m,
    wind_speed_kmh: current.wind_speed_10m,
    condition: describeCode(current.weather_code),
    observed_at: current.time,
    timezone: data.timezone,
  };
}

/**
 * Fetches a multi-day daily forecast for a given latitude/longitude.
 */
async function getForecast(latitude, longitude, days = 5) {
  const clampedDays = Math.min(Math.max(Number(days) || 5, 1), 16);

  const { data } = await axios.get(WEATHER_URL, {
    params: {
      latitude,
      longitude,
      daily: "temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum",
      timezone: "auto",
      forecast_days: clampedDays,
    },
  });

  const { time, temperature_2m_max, temperature_2m_min, weather_code, precipitation_sum } =
    data.daily;

  return time.map((date, i) => ({
    date,
    max_temp_celsius: temperature_2m_max[i],
    min_temp_celsius: temperature_2m_min[i],
    precipitation_mm: precipitation_sum[i],
    condition: describeCode(weather_code[i]),
  }));
}

module.exports = { geocodeCity, getCurrentWeather, getForecast };
