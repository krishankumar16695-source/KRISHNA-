require("dotenv").config();
const express = require("express");
const cors = require("cors");
const weatherRoutes = require("./routes/weather");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Simple request logger
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl}`);
  next();
});

app.get("/", (req, res) => {
  res.json({
    name: "Weather API",
    status: "running",
    endpoints: {
      health: "GET /health",
      current_weather: "GET /api/weather?city=Delhi  (or ?lat=&lon=)",
      forecast: "GET /api/forecast?city=Delhi&days=5  (or ?lat=&lon=&days=)",
    },
  });
});

app.get("/health", (req, res) => {
  res.json({ status: "ok", uptime_seconds: process.uptime() });
});

app.use("/api", weatherRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// Centralized error handler
app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: err.message || "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Weather API running at http://localhost:${PORT}`);
});
