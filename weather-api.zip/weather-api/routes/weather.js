const express = require("express");
const router = express.Router();
const {
  geocodeCity,
  getCurrentWeather,
  getForecast,
} = require("../services/weatherService");

/**
 * Resolves a request's location from either ?city= or ?lat=&lon=
 * query params. Throws a 400 error if neither is provided.
 */
async function resolveLocation(req) {
  const { city, lat, lon } = req.query;

  if (city) {
    const place = await geocodeCity(city);
    return { ...place, source: "city" };
  }

  if (lat && lon) {
    return {
      name: null,
      country: null,
      latitude: Number(lat),
      longitude: Number(lon),
      source: "coordinates",
    };
  }

  const err = new Error("Provide either ?city=CityName or ?lat=&lon=");
  err.status = 400;
  throw err;
}

// GET /api/weather?city=Delhi
// GET /api/weather?lat=28.61&lon=77.21
router.get("/weather", async (req, res, next) => {
  try {
    const location = await resolveLocation(req);
    const current = await getCurrentWeather(location.latitude, location.longitude);

    res.json({
      location: {
        name: location.name,
        country: location.country,
        latitude: location.latitude,
        longitude: location.longitude,
      },
      current,
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/forecast?city=Mumbai&days=5
// GET /api/forecast?lat=19.07&lon=72.87&days=3
router.get("/forecast", async (req, res, next) => {
  try {
    const location = await resolveLocation(req);
    const forecast = await getForecast(
      location.latitude,
      location.longitude,
      req.query.days
    );

    res.json({
      location: {
        name: location.name,
        country: location.country,
        latitude: location.latitude,
        longitude: location.longitude,
      },
      forecast,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
