# Weather API

Ek simple, fully-working Express.js API jo [Open-Meteo](https://open-meteo.com/) ka data wrap karti hai.
**Koi API key nahi chahiye** — Open-Meteo free aur completely open hai.

## Setup (sirf 3 steps)

```bash
cd weather-api
npm install
npm start
```

Server `http://localhost:3000` par chal jayega.

## Endpoints

### 1. Welcome / Info
```
GET /
```

### 2. Health check
```
GET /health
```

### 3. Current weather (city name se)
```
GET /api/weather?city=Delhi
```

### 4. Current weather (lat/lon se)
```
GET /api/weather?lat=28.61&lon=77.21
```

**Example response:**
```json
{
  "location": { "name": "Delhi", "country": "India", "latitude": 28.65, "longitude": 77.23 },
  "current": {
    "temperature_celsius": 38.2,
    "humidity_percent": 22,
    "wind_speed_kmh": 11.4,
    "condition": "Clear sky",
    "observed_at": "2026-06-16T15:00",
    "timezone": "Asia/Kolkata"
  }
}
```

### 5. Forecast (multi-day)
```
GET /api/forecast?city=Mumbai&days=5
GET /api/forecast?lat=19.07&lon=72.87&days=3
```

`days` optional hai (default 5, max 16).

## Testing karne ke liye

Browser me URL khol do, ya curl use karo:
```bash
curl "http://localhost:3000/api/weather?city=Jaipur"
```

Ya Postman/Thunder Client me GET request bhej do.

## Project structure
```
weather-api/
├── server.js              # main entry point
├── routes/weather.js       # API routes
├── services/weatherService.js  # Open-Meteo calls + data formatting
└── package.json
```

## Customize / Extend
- Port change karna ho to `.env` file banao aur `PORT=4000` daalo.
- Aur fields chahiye (e.g. UV index, sunrise/sunset) to `weatherService.js` me Open-Meteo ke params me add kar do — unki [docs](https://open-meteo.com/en/docs) dekho.
