const request = require('supertest');
const app = require('../src/app');

describe('Calculator API', () => {
  describe('POST /api/v1/calculate/add', () => {
    it('adds two numbers correctly', async () => {
      const res = await request(app).post('/api/v1/calculate/add').send({ numbers: [2, 3] });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.result).toBe(5);
    });

    it('adds more than two numbers correctly', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .send({ numbers: [2, 3, 5, 10] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(20);
    });

    it('handles negative numbers and decimals', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .send({ numbers: [-5, 2.5] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(-2.5);
    });
  });

  describe('POST /api/v1/calculate/subtract', () => {
    it('subtracts sequentially left-to-right', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/subtract')
        .send({ numbers: [10, 2, 3] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(5);
    });
  });

  describe('POST /api/v1/calculate/multiply', () => {
    it('multiplies numbers correctly', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/multiply')
        .send({ numbers: [2, 3, 4] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(24);
    });

    it('handles zero correctly (result is zero, not an error)', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/multiply')
        .send({ numbers: [5, 0] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(0);
    });
  });

  describe('POST /api/v1/calculate/divide', () => {
    it('divides sequentially left-to-right', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/divide')
        .send({ numbers: [100, 5, 2] });
      expect(res.status).toBe(200);
      expect(res.body.result).toBe(10);
    });

    it('returns 400 when dividing by zero', async () => {
      const res = await request(app).post('/api/v1/calculate/divide').send({ numbers: [10, 0] });
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.message).toMatch(/division by zero/i);
    });
  });

  describe('Input validation', () => {
    it('rejects a missing "numbers" field', async () => {
      const res = await request(app).post('/api/v1/calculate/add').send({});
      expect(res.status).toBe(400);
    });

    it('rejects "numbers" that is not an array', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .send({ numbers: 'not-an-array' });
      expect(res.status).toBe(400);
    });

    it('rejects fewer than two numbers', async () => {
      const res = await request(app).post('/api/v1/calculate/add').send({ numbers: [5] });
      expect(res.status).toBe(400);
    });

    it('rejects non-numeric values inside the array', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .send({ numbers: [1, 'two'] });
      expect(res.status).toBe(400);
    });

    it('rejects NaN and Infinity', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .send({ numbers: [1, null] });
      expect(res.status).toBe(400);
    });

    it('rejects malformed JSON bodies', async () => {
      const res = await request(app)
        .post('/api/v1/calculate/add')
        .set('Content-Type', 'application/json')
        .send('{ not valid json');
      expect(res.status).toBe(400);
    });
  });

  describe('GET /health', () => {
    it('returns ok status', async () => {
      const res = await request(app).get('/health');
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('ok');
    });
  });

  describe('GET /', () => {
    it('returns API metadata', async () => {
      const res = await request(app).get('/');
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Calculator API');
    });
  });

  describe('Unknown routes', () => {
    it('returns 404 for an unknown calculate route', async () => {
      const res = await request(app).get('/api/v1/calculate/unknown');
      expect(res.status).toBe(404);
    });

    it('returns 404 for a completely unrelated path', async () => {
      const res = await request(app).get('/totally/not/a/route');
      expect(res.status).toBe(404);
    });
  });
});
