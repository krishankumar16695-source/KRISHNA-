# Calculator API

A professional REST API for basic arithmetic — addition, subtraction, multiplication, and division — built with Node.js and Express.

## Features

- Four arithmetic endpoints that each accept an array of two or more numbers
- Centralized, consistent JSON error format across the whole API
- Input validation (missing fields, wrong types, non-finite values, division by zero, oversized payloads)
- Security headers via `helmet`, configurable CORS via `cors`
- Request logging via `morgan`
- Rate limiting via `express-rate-limit`
- Health check endpoint for uptime monitors / load balancers
- Clean MVC-style structure (routes → controllers → services)
- Full Jest + Supertest test suite
- Postman collection for manual testing

## Project structure

```
calculator-api/
├── src/
│   ├── app.js                       # Express app: middleware + routes
│   ├── server.js                    # Entry point (starts the HTTP server)
│   ├── config/index.js              # Centralized environment config
│   ├── routes/calculator.routes.js  # Route definitions
│   ├── controllers/calculator.controller.js
│   ├── services/calculator.service.js  # Pure arithmetic logic
│   ├── middleware/errorHandler.js   # Centralized error + 404 handling
│   └── utils/
│       ├── ApiError.js              # Custom error class with status codes
│       ├── asyncHandler.js          # Wraps async routes for error handling
│       └── validateNumbers.js       # Request body validation
├── tests/calculator.test.js         # Jest + Supertest test suite
├── postman/calculator-api.postman_collection.json
├── .env.example
└── package.json
```

## Requirements

- Node.js 18 or later
- npm

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Copy environment template (optional — sensible defaults are built in)
cp .env.example .env

# 3. Start the server
npm start          # production mode
npm run dev        # auto-restarts on file changes (Node's built-in --watch)
```

The server listens on `http://localhost:3000` by default.

## Environment variables

| Variable                   | Default       | Description                          |
|----------------------------|----------------|---------------------------------------|
| `PORT`                     | `3000`         | Port the server listens on            |
| `NODE_ENV`                 | `development`  | `development`, `production`, or `test`|
| `RATE_LIMIT_WINDOW_MS`     | `900000` (15m) | Rate limit window                     |
| `RATE_LIMIT_MAX_REQUESTS`  | `100`          | Max requests per window, per IP       |

## API reference

All calculation endpoints accept `POST` requests with a JSON body:

```json
{ "numbers": [10, 5, 2] }
```

`numbers` must contain **at least two** finite numbers (max 1000). Operations are applied **left to right**: `subtract` and `divide` compute `numbers[0] - numbers[1] - numbers[2]...` and `numbers[0] / numbers[1] / numbers[2]...` respectively.

| Method | Endpoint                        | Description                  |
|--------|----------------------------------|-------------------------------|
| GET    | `/health`                        | Health check                  |
| GET    | `/`                               | API metadata / endpoint list  |
| POST   | `/api/v1/calculate/add`          | Sum of all numbers            |
| POST   | `/api/v1/calculate/subtract`     | Sequential subtraction        |
| POST   | `/api/v1/calculate/multiply`     | Product of all numbers        |
| POST   | `/api/v1/calculate/divide`       | Sequential division           |

### Example request

```bash
curl -X POST http://localhost:3000/api/v1/calculate/add \
  -H "Content-Type: application/json" \
  -d '{"numbers": [10, 5, 2]}'
```

### Success response (`200`)

```json
{
  "success": true,
  "operation": "add",
  "input": [10, 5, 2],
  "result": 17
}
```

### Error response

All errors share the same shape:

```json
{
  "success": false,
  "error": {
    "message": "Division by zero is not allowed.",
    "details": null
  }
}
```

| Status | Cause                                                        |
|--------|----------------------------------------------------------------|
| 400    | Missing/invalid `numbers`, fewer than 2 values, non-numeric values, division by zero, malformed JSON |
| 404    | Unknown route                                                 |
| 429    | Rate limit exceeded                                            |
| 500    | Unexpected server error                                       |

## Testing

```bash
npm test
```

Runs the full Jest + Supertest suite covering every operation, edge cases (zero, negatives, decimals), and all validation/error paths.

## Manual testing with Postman

Import `postman/calculator-api.postman_collection.json` into Postman — it includes a ready-made request for every endpoint plus the health check.

## Notes on precision

This API uses native JavaScript floating-point arithmetic. As with any IEEE-754 floating-point system, some decimal operations (e.g. `0.1 + 0.2`) may not return an exact decimal value. For applications requiring exact decimal precision (e.g. financial calculations), consider a decimal library such as `decimal.js`.

## License

MIT
