const app = require('./app');
const config = require('./config');

const server = app.listen(config.port, () => {
  console.log(`Calculator API running on port ${config.port} [${config.nodeEnv}]`);
});

// Fail loudly (and exit) on unhandled promise rejections rather than
// continuing to run in a corrupted state.
process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err);
  server.close(() => process.exit(1));
});

process.on('SIGTERM', () => {
  console.log('SIGTERM received: closing server gracefully.');
  server.close(() => process.exit(0));
});

module.exports = server;
