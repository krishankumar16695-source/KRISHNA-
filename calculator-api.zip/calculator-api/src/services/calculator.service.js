const ApiError = require('../utils/ApiError');

/** Sums every number in the array. */
const add = (numbers) => numbers.reduce((sum, n) => sum + n, 0);

/** Subtracts left-to-right: numbers[0] - numbers[1] - numbers[2] ... */
const subtract = (numbers) => numbers.reduce((acc, n) => acc - n);

/** Multiplies every number in the array. */
const multiply = (numbers) => numbers.reduce((product, n) => product * n, 1);

/** Divides left-to-right: numbers[0] / numbers[1] / numbers[2] ... */
const divide = (numbers) =>
  numbers.reduce((acc, n) => {
    if (n === 0) {
      throw new ApiError(400, 'Division by zero is not allowed.');
    }
    return acc / n;
  });

module.exports = { add, subtract, multiply, divide };
