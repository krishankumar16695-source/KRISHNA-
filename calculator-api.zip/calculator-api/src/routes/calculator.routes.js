const express = require('express');
const controller = require('../controllers/calculator.controller');

const router = express.Router();

router.post('/add', controller.add);
router.post('/subtract', controller.subtract);
router.post('/multiply', controller.multiply);
router.post('/divide', controller.divide);

module.exports = router;
