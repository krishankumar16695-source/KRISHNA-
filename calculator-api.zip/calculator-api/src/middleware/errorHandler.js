const ApiError = require('../utils/ApiError');

/**
 * Centralized Express error handler. Must be registered after all routes.
 * Known operational errors (ApiError) return their own status/message;
 * anything unexpected is logged server-side and reported generically
 * to avoid leaking internals to the client.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      success: false,
      error: {
        message: err.message,
        details: err.details,
      },
    });
  }

  // express.json() throws a SyntaxError for malformed JSON bodies.
  if (err instanceof SyntaxError && err.type === 'entity.parse.failed') {
    return res.status(400).json({
      success: false,
      error: { message: 'Request body contains malformed JSON.' },
    });
  }

  console.error('Unexpected error:', err);
  return res.status(500).json({
    success: false,
    error: { message: 'Internal server error.' },
  });
}

/** Catches requests to routes that don't exist. Register before errorHandler. */
function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    error: { message: `Route ${req.method} ${req.originalUrl} was not found.` },
  });
}

module.exports = { errorHandler, notFoundHandler };
