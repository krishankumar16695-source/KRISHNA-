const asyncHandler = require('../utils/asyncHandler');
const validateNumbers = require('../utils/validateNumbers');
const calculatorService = require('../services/calculator.service');

/**
 * Builds an Express handler for a given arithmetic operation: validates
 * the request body, runs the operation, and returns a consistent
 * success envelope.
 */
function buildHandler(operation, fn) {
  return asyncHandler(async (req, res) => {
    const numbers = validateNumbers(req.body);
    const result = fn(numbers);

    res.status(200).json({
      success: true,
      operation,
      input: numbers,
      result,
    });
  });
}

module.exports = {
  add: buildHandler('add', calculatorService.add),
  subtract: buildHandler('subtract', calculatorService.subtract),
  multiply: buildHandler('multiply', calculatorService.multiply),
  divide: buildHandler('divide', calculatorService.divide),
};
