const ApiError = require('./ApiError');

const MAX_OPERANDS = 1000;

/**
 * Validates that `body.numbers` is an array of at least two finite numbers
 * (and not an unreasonably large array). Throws an ApiError(400) with a
 * descriptive message on any validation failure; otherwise returns the
 * validated array.
 *
 * @param {*} body - parsed JSON request body
 * @returns {number[]} validated numbers
 */
function validateNumbers(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new ApiError(400, 'Request body must be a JSON object, e.g. { "numbers": [1, 2, 3] }.');
  }

  const { numbers } = body;

  if (numbers === undefined) {
    throw new ApiError(400, 'Request body is missing the required "numbers" field.');
  }

  if (!Array.isArray(numbers)) {
    throw new ApiError(400, '"numbers" must be an array of numbers.');
  }

  if (numbers.length < 2) {
    throw new ApiError(400, '"numbers" must contain at least two values.');
  }

  if (numbers.length > MAX_OPERANDS) {
    throw new ApiError(400, `"numbers" cannot contain more than ${MAX_OPERANDS} values.`);
  }

  numbers.forEach((n, idx) => {
    if (typeof n !== 'number' || Number.isNaN(n) || !Number.isFinite(n)) {
      throw new ApiError(
        400,
        `Invalid value at index ${idx}: ${JSON.stringify(n)}. Every element of "numbers" must be a finite number.`
      );
    }
  });

  return numbers;
}

module.exports = validateNumbers;
