/**
 * Wraps an async route handler so any rejected promise or thrown error
 * is forwarded to Express's `next()` instead of crashing the process
 * or requiring a try/catch in every controller.
 */
module.exports = function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
