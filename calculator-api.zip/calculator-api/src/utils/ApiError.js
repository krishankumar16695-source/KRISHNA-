/**
 * Operational error with an HTTP status code attached.
 * Thrown anywhere in the request lifecycle and caught by the
 * centralized error-handling middleware in middleware/errorHandler.js.
 */
class ApiError extends Error {
  constructor(statusCode, message, details = null) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.details = details;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = ApiError;
