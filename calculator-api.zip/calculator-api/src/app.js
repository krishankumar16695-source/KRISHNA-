const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const config = require('./config');
const calculatorRoutes = require('./routes/calculator.routes');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');

const app = express();

// Security headers
app.use(helmet());

// Cross-origin requests
app.use(cors());

// Request logging (concise in dev, standard "combined" format in prod)
app.use(morgan(config.nodeEnv === 'production' ? 'combined' : 'dev'));

// Parse JSON bodies; reject anything unreasonably large
app.use(express.json({ limit: '10kb' }));

// Basic abuse protection
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: { message: 'Too many requests. Please try again later.' },
  },
});
app.use(limiter);

// Health check (useful for uptime monitors / load balancers)
app.get('/health', (req, res) => {
  res.status(200).json({ success: true, status: 'ok', uptime: process.uptime() });
});

// API root: quick reference of available endpoints
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    name: 'Calculator API',
    version: '1.0.0',
    endpoints: {
      health: 'GET /health',
      add: 'POST /api/v1/calculate/add',
      subtract: 'POST /api/v1/calculate/subtract',
      multiply: 'POST /api/v1/calculate/multiply',
      divide: 'POST /api/v1/calculate/divide',
    },
    requestFormat: { numbers: [1, 2, 3] },
  });
});

app.use('/api/v1/calculate', calculatorRoutes);

// 404 for anything unmatched, then the centralized error handler.
// Order matters: notFoundHandler must come after all real routes,
// and errorHandler must be the very last middleware registered.
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
